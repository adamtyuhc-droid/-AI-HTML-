---
name: stats-notes
description: 讀取使用者提供的數學理工教材內容（機率、統計、線代、微積分、輸送現象等），理解後產出精美的繁體中文互動 HTML 學習筆記（含 KaTeX 數學渲染、sidebar 導覽、深色設計系統），並插入到 C:\Users\Ray\Desktop\統計筆記\notes.html 單一主檔。當使用者說「存」、「幫我存」、「整理成筆記」、「做成筆記」、「存到筆記」、「直接存」、或提供教材內容後要整理時，務必使用此 skill。也適用於使用者說「教我完再存」、「這也是XX單元的」等情境。
---

# 統計筆記 Skill — 單一主檔插入模式

## 核心架構

所有筆記存在**同一個 HTML 主檔**：`C:\Users\Ray\Desktop\統計筆記\notes.html`

新內容透過 **HTML 註解插入標記** 寫入，不重建整個檔案。

---

## 插入標記位置

| 標記 | 用途 |
|------|------|
| `<!-- ADD_CHAPTER_transport -->` | Ch.10 新章節（§10.x）插入點 |
| `<!-- ADD_CHAPTER_ch11 -->` | Ch.11 新章節（§11.x）插入點 |
| `<!-- ADD_CHAPTER_ch12 -->` | Ch.12+ 及 Ch.13/14/15 等新章節插入點 |
| `<!-- ADD_SUBJECT -->` | 新科目 subject-block 插入點 |
| `<!-- ADD_PAGE -->` | 新頁面 div 插入點（位於 `</main>` 前）|

---

## Sidebar 三層結構

```
subject-block（大標，科目名稱，例如「輸送現象」）
  ├── chapter-label（Chapter 10 / Chapter 11 等分隔標籤）
  └── chapter-group（小標，例如 §12.2 層流管內穩態對流熱傳）
        └── nav-item（每個頁面，帶 tag + 簡短標題）
```

### Subject-block HTML

```html
<div class="subject-block open" id="subj-XXXX">
  <div class="subject-header" onclick="toggleSubject('subj-XXXX')">
    <span class="subject-title">科目名稱</span>
    <span class="subject-chevron">▶</span>
  </div>
  <div class="subject-body">
    <div class="chapter-label">Chapter N</div>
    <!-- §N.x chapter-groups -->
    <!-- ADD_CHAPTER_xxx -->
  </div>
</div>
```

### Chapter-label HTML（章節分隔）

```html
<div class="chapter-label">Chapter 12</div>
```

### Chapter-group HTML（§N.x）

```html
<div class="chapter-group open" id="ch-N-x">
  <div class="chapter-group-header" onclick="toggleChapter('ch-N-x')">
    <span class="chapter-group-title">§N.x 章節名稱</span>
    <span class="chapter-chevron">▶</span>
  </div>
  <div class="chapter-group-body">
    <div class="nav-item" onclick="show('t_Nx_yyy', this)">
      <span class="nav-tag tag-def">定義</span>
      <span class="nav-label">頁面簡短標題</span>
    </div>
    <!-- 更多 nav-item -->
  </div>
</div>
```

---

## Nav Tag 類型

| tag class | 顏色 | 用於 |
|-----------|------|------|
| `tag-def` | 藍色 | 定義、術語、設定 |
| `tag-thm` | 紫色 | 定理、推論、結論 |
| `tag-ex` | 綠色 | 例題、數值計算 |
| `tag-rmk` | 珊瑚色 | 備注、直觀解釋、提醒 |
| `tag-method` | 琥珀色 | 方法、演算法、推導流程 |

---

## 頁面 div 結構

每個頁面是一個 `<div id="t_Nx_yyy" class="page">` 區塊，插在 `<!-- ADD_PAGE -->` 之前。

### 完整頁面範本

```html
<div id="t_Nx_yyy" class="page">
  <div class="page-header">
    <span class="tag label-def">定義</span>
    <h2>§N.x 標題</h2>
    <p class="subtitle">一句話說明此頁解決什麼問題或為什麼重要。</p>
  </div>

  <div class="block">
    <span class="block-label label-def">定義</span>
    <p>內文說明...</p>
    <div class="math-display">$$數學公式$$</div>
  </div>

  <div class="block">
    <span class="block-label label-rmk">直觀解釋</span>
    <p>白話說明...</p>
  </div>
</div>

<hr class="divider">
```

---

## Block Label 類型

| class | 顏色 | 用於 |
|-------|------|------|
| `label-def` | 藍色 | 定義、符號說明 |
| `label-thm` | 紫色 | 定理主體 |
| `label-proof` | 灰色 | 證明過程 |
| `label-ex` | 綠色 | 例題 |
| `label-step` | 琥珀色 | 解題步驟 |
| `label-rmk` | 珊瑚色 | 備注、直觀解釋 |
| `label-method` | 琥珀色 | 方法、推導流程 |
| `label-key` | 藍色 | 關鍵設定 |
| `label-ans` | 琥珀色 | 答案框標籤 |

---

## 常用 Block 元件

### 網格佈局

```html
<div class="grid-2"> <!-- 或 grid-3, grid-4 -->
  <div class="info-cell">
    <strong>標題</strong><br>內容說明
  </div>
  <div class="info-cell">...</div>
</div>
```

### 步驟列

```html
<div class="step-row">
  <div class="step-num">1</div>
  <div>步驟說明，可含行內數學 $E[X]$</div>
</div>
```

### 答案框

```html
<div class="ans-box">$$最終答案公式$$</div>
```

### 表格

```html
<table class="counting-table">
  <thead><tr><th>欄位A</th><th>欄位B</th></tr></thead>
  <tbody>
    <tr><td>資料</td><td>資料</td></tr>
  </tbody>
</table>
```

---

## 執行流程

### Step 1：理解教材內容

閱讀使用者提供的教材圖片或文字，識別：
- 章節編號（§N.x）
- 內容類型（定義/定理/例題/備注/方法）
- 需要幾個頁面（通常每個概念或例題一頁，3–7 頁/章節）

### Step 2：確認插入位置

- 用 `Grep` 搜尋 `<!-- ADD_CHAPTER_ch12 -->` 等標記，確認存在
- 若是新科目，搜尋 `<!-- ADD_SUBJECT -->`
- 若是新章節分類（如 Chapter 13），在現有 chapter 標記前加 `<div class="chapter-label">Chapter N</div>`

### Step 3：插入 Sidebar

用 `Edit` 工具，在對應 `<!-- ADD_CHAPTER_xxx -->` 標記**之前**插入 chapter-group HTML。

**規則**：
- 新的 §N.x 插入對應章節的 ADD 標記前
- 若跨章（如從 Ch.12 跳到 Ch.13），先插入 `<div class="chapter-label">Chapter 13</div>`，再插入章節 group

### Step 4：插入頁面 divs

用 `Edit` 工具，在 `<!-- ADD_PAGE -->` 標記**之前**插入所有頁面 div。

頁面之間用 `<hr class="divider">` 分隔。
最後一個頁面之後緊接 `<!-- ADD_PAGE -->`。

### Step 5：確認品質

- 所有 page `id` 唯一，且與 sidebar `onclick="show('id', this)"` 對應
- KaTeX 數學語法正確（`$$...$$` 顯示型，`$...$` 行內）
- 每個頁面有 subtitle（說明「為什麼重要」）
- 定義/定理頁必有 `label-rmk` 直觀解釋

---

## KaTeX 語法速查

| 要表達的 | LaTeX | 備注 |
|----------|-------|------|
| 分數 | `\frac{a}{b}` | |
| 偏微分 | `\frac{\partial f}{\partial x}` | |
| 積分 | `\int_a^b f\,dx` | |
| 求和 | `\sum_{i=1}^{n}` | |
| 希臘字 | `\alpha \beta \lambda \mu \sigma \theta` | |
| 向量 | `\mathbf{v}` 或 `\vec{v}` | |
| 矩陣 | `\begin{pmatrix}a&b\\c&d\end{pmatrix}` | |
| 條件機率 | `P(A \mid B)` | 用 `\mid` 不是 `\|` |
| 範數 | `\|\mathbf{v}\|` | |
| 絕對值 | `|x|` | |

**行內**：`$公式$`（嵌在文字中）
**顯示型**：`$$公式$$`（放在 `.math-display` 或 `.ans-box` 內）

---

## 內容品質規範

1. **subtitle 必填**：每個 page-header 的 subtitle 說明「這個東西解決什麼問題」
2. **直觀解釋**：每個定義/定理後附 `label-rmk` block 用白話說明
3. **例題完整步驟**：用 `step-row` 呈現每步，`ans-box` 框住答案
4. **繁體中文為主**：說明文字用繁體中文，術語第一次出現附英文
5. **page id 命名**：`t_` 開頭，如 `t_12_2_sl`、`t_13_1_eq`
6. **章節 id 命名**：`ch-` 開頭，如 `ch-12-2`、`ch-13-1`

---

## 注意事項

- 永遠用 `Edit` 工具插入，不要用 `Write` 重寫整個 notes.html
- 插入前先用 `Grep` 確認標記位置
- CSS 設計系統不得更改
- 每次存完告知使用者「§N.x 存好了，共 X 頁」
