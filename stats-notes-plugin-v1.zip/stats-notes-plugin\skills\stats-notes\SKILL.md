---
name: stats-notes
description: 將教材內容（數學、理工、任何科目）轉為精美繁體中文互動 HTML 學習筆記（KaTeX 數學渲染、sidebar 導覽、深色主題）。第一次使用自動詢問存放路徑並建立筆記檔。當使用者說「存」、「幫我存」、「整理成筆記」、「做成筆記」、「存到筆記」時觸發。
---

# Learning Notes Skill

## 觸發條件
使用者說：「存」、「幫我存」、「整理成筆記」、「做成筆記」、「存到筆記」、「直接存」、「教我完再存」、「這也是 XX 單元的」

---

## Step 0：初始化 — 取得筆記路徑

### 0a. 讀取設定檔

用 `Read` 工具嘗試讀取以下路徑（優先順序）：
1. `[SKILL_BASE_DIR]/config.json`（此 skill 目錄下）
2. `~/.claude/skills/stats-notes/config.json`

若成功讀取且包含 `notes_path` 欄位 → 使用該路徑，跳至 Step 0c。

**config.json 格式：**
```json
{
  "notes_path": "C:\\Users\\你的名字\\Desktop\\學習筆記\\notes.html"
}
```

### 0b. 首次設定（找不到 config.json 時）

詢問使用者：
> 「請問你想把學習筆記存在哪個資料夾？（輸入完整路徑，例如：C:\Users\你的名字\Desktop\學習筆記）」

收到路徑後：
1. 在該路徑後加上 `\notes.html` 作為目標檔案
2. 用 `Write` 工具將 config.json 存到 `[SKILL_BASE_DIR]/config.json`：
```json
{
  "notes_path": "使用者輸入的路徑\\notes.html"
}
```
3. 繼續 Step 0c

### 0c. 確認 HTML 主檔存在

用 `Read` 嘗試讀取 `notes_path`：
- **存在** → 直接進入 Step 1
- **不存在** → 讀取同目錄下的 `template.html`（`[SKILL_BASE_DIR]/template.html`），用 `Write` 寫入 `notes_path`，再進入 Step 1

---

## Step 1：理解教材內容

閱讀使用者提供的圖片或文字，識別：
- **所屬科目**（若未知，詢問使用者）
- **章節編號**（§N.x）
- **內容類型**：定義 / 定理 / 例題 / 備注 / 方法
- **頁面數量**（每個概念或例題一頁，通常 2–6 頁）

---

## Step 2：確認科目是否已存在

用 `Grep` 搜尋 `notes_path` 中是否有 `id="subj-[科目id]"`：

- **已存在** → 找到對應的 `<!-- ADD_CHAPTER_xxx -->` 標記，進入 Step 4
- **不存在** → 執行 Step 3（新增科目）

---

## Step 3：新增科目（首次）

### 3a. 在 Sidebar 新增 subject-block

用 `Edit` 在 `<!-- ADD_SUBJECT -->` **之前**插入：

```html
<div class="subject-block open" id="subj-[英文id]">
  <div class="subject-header" onclick="toggleSubject('subj-[英文id]')">
    <div class="subject-header-left">
      <div class="subject-dot" style="background:[顏色];"></div>
      <span class="subject-title">[科目中文名稱]</span>
    </div>
    <span class="subject-chevron">▶</span>
  </div>
  <div class="subject-body">
    <div class="chapter-label">Chapter N · [章節名稱]</div>
    <!-- ADD_CHAPTER_[科目縮寫]_ch1 -->
  </div>
</div>
```

**科目顏色建議：**
- 數學/統計：`#6aabdc`（藍）
- 程序控制：`#e8954a`（橙）
- 化工/輸送：`#5dcaa5`（綠）
- 物理：`#9b8fe8`（紫）
- 其他：自選

### 3b. 在首頁新增科目卡片

找到 `<div class="subject-card-grid">` 並在其中新增：

```html
<div class="subject-card" onclick="openSubject('subj-[英文id]')">
  <div class="sc-label"><span class="sc-dot" style="background:[顏色];"></span>[英文科目名]</div>
  <h3>[科目中文名] Ch.N</h3>
  <p>[一句話描述這個科目的內容]</p>
  <div class="sc-count">0</div>
</div>
```

---

## Step 4：插入 Sidebar chapter-group

用 `Edit` 在對應 `<!-- ADD_CHAPTER_xxx -->` **之前**插入：

```html
<div class="chapter-group open" id="ch-N-x">
  <div class="chapter-group-header" onclick="toggleChapter('ch-N-x')">
    <span class="chapter-group-title">§N.x 章節名稱</span>
    <span class="chapter-chevron">▶</span>
  </div>
  <div class="chapter-group-body">
    <div class="nav-item" onclick="show('t_Nx_yyy', this)">
      <span class="nav-tag tag-method">方法</span>
      <span class="nav-label">頁面簡短標題</span>
    </div>
    <!-- 更多 nav-item 依內容頁面數量增加 -->
  </div>
</div>
```

**Nav Tag 類型：**
| class | 顏色 | 用於 |
|-------|------|------|
| `tag-def` | 藍 | 定義、術語 |
| `tag-thm` | 紫 | 定理、結論 |
| `tag-ex` | 綠 | 例題、計算 |
| `tag-rmk` | 珊瑚 | 備注、提醒 |
| `tag-method` | 琥珀 | 方法、推導 |

---

## Step 5：插入頁面 divs

用 `Edit` 在 `<!-- ADD_PAGE -->` **之前**插入所有頁面，每頁用 `<hr class="divider">` 分隔：

```html
<div id="t_Nx_yyy" class="page">
  <div class="page-header">
    <span class="tag label-method">推導</span>
    <h2>§N.x 標題</h2>
    <p class="subtitle">一句話說明此頁解決什麼問題或為什麼重要。</p>
  </div>

  <div class="block">
    <span class="block-label label-def">定義</span>
    <p>說明文字...</p>
    <div class="math-display">$$數學公式$$</div>
  </div>

  <div class="block">
    <span class="block-label label-rmk">直觀解釋</span>
    <p>白話說明，讓人真正理解為什麼...</p>
  </div>
</div>

<hr class="divider">
```

**Block Label 類型：**
| class | 用於 |
|-------|------|
| `label-def` | 定義、符號說明 |
| `label-thm` | 定理主體 |
| `label-proof` | 證明過程 |
| `label-ex` | 例題 |
| `label-step` | 解題步驟 |
| `label-rmk` | 備注、直觀解釋 |
| `label-method` | 方法、推導流程 |
| `label-ans` | 答案框標籤 |

---

## Step 6：更新首頁卡片計數

找到對應科目卡片的 `<div class="sc-count">N</div>`，將數字更新為當前總頁數。

---

## Step 7：品質確認

- [ ] 所有 page id 唯一，且與 sidebar `onclick="show('id', this)"` 對應
- [ ] KaTeX：`$$...$$`（顯示型）、`$...$`（行內）
- [ ] 每頁有 subtitle（說明「為什麼重要」）
- [ ] 定義/定理頁必有 `label-rmk` 直觀解釋
- [ ] 告知使用者：「§N.x 存好了，共 X 頁 ✓」

---

## 常用 HTML 元件

### 網格
```html
<div class="grid-2">
  <div class="info-cell"><strong>標題</strong><br>說明內容</div>
  <div class="info-cell"><strong>標題</strong><br>說明內容</div>
</div>
```

### 步驟列
```html
<div class="step-row">
  <div class="step-num">1</div>
  <div>步驟說明，可含行內數學 $E[X] = \mu$</div>
</div>
```

### 答案框
```html
<div class="ans-box">$$最終答案公式$$</div>
```

### 表格
```html
<table class="counting-table">
  <thead><tr><th>欄A</th><th>欄B</th></tr></thead>
  <tbody><tr><td>資料</td><td>資料</td></tr></tbody>
</table>
```

---

## KaTeX 速查

| 符號 | LaTeX |
|------|-------|
| 分數 | `\frac{a}{b}` |
| 偏微分 | `\frac{\partial f}{\partial x}` |
| 積分 | `\int_a^b f\,dx` |
| 求和 | `\sum_{i=1}^{n}` |
| 希臘字 | `\alpha \beta \tau \rho \sigma \theta \lambda` |
| 矩陣 | `\begin{pmatrix}a&b\\c&d\end{pmatrix}` |

**行內**：`$公式$` ／ **顯示型**：`$$公式$$`（放在 `.math-display` 或 `.ans-box` 內）

---

## 內容品質規範

1. **subtitle 必填**：每頁說明「這個東西解決什麼問題/為什麼重要」
2. **直觀解釋**：每個定義/定理後必有 `label-rmk` 白話說明
3. **例題步驟完整**：用 `step-row` 呈現每步，`ans-box` 框住答案
4. **繁體中文為主**：術語第一次出現附英文
5. **page id 命名**：`t_` 開頭，如 `t_21_thermal`、`t_12_sl`
6. **chapter-group id**：`ch-` 開頭，如 `ch-2-1`、`ch-12-3`

---

## 注意事項

- 永遠用 `Edit` 插入，**絕不** 用 `Write` 重寫整個 notes.html
- 插入前先用 `Grep` 確認標記位置
- CSS 設計系統不得更改
- 若使用者說「換個科目」或「這是新科目」，先執行 Step 3
